package com.capgemini.contribute.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.conrribute.entity.Contribute;

public interface ContributeRepo extends MongoRepository<Contribute, String>{

}
