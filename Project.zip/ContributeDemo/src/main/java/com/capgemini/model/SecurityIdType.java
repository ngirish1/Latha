
package com.capgemini.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;

public enum SecurityIdType {

    @JsonProperty("CUSIP")
    CUSIP("CUSIP"),
    @JsonProperty("ISIN")
    ISIN("ISIN"),
    @JsonProperty("SEDOL")
    SEDOL("SEDOL"),
    @JsonProperty("SICC")
    SICC("SICC"),
    @JsonProperty("VALOR")
    VALOR("VALOR"),
    @JsonProperty("WKN")
    WKN("WKN");
    private final String value;
    private final static Map<String, SecurityIdType> VALUE_CACHE = new HashMap<String, SecurityIdType>();

    static {
        for (SecurityIdType c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private SecurityIdType(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static SecurityIdType fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
