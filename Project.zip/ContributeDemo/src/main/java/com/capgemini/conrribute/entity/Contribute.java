package com.capgemini.conrribute.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
//import javax.persistence.Entity;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.capgemini.model.SecurityIdType;

@Document
public class Contribute {
    @Id
    //@Column(name = "id", unique = true, nullable = false)
    //@column()
	private String _id;
    @Field
	private SecurityIdType securityIdType;
	@Field
	private int EmployerMatchPercentage;
	@Field
	private int EmployerMatchAmount;
	@Field
	private int EmployeePreTaxAmount;
	@Field
	private int EmployeePreTaxPercentage;
	@Field
	private int EmployeeAfterTaxAmount;
	@Field
	private int EmployeeAfterTaxPercentage;
	@Field
	private int EmployeeDeferPreTaxAmount;
	@Field
	private int EmployeeDeferPreTaxPercentage;
	@Field
	private int EmployeeYearToDate;
	@Field
	private int EmployerYearToDate;
	@Field
	private int RolloverContributionPercentage;
	@Field
	private int RolloverContributionAmount;
	/*public Contribute(String _id, SecurityIdType securityIdType, int employerMatchPercentage, int employerMatchAmount,
			int employeePreTaxAmount, int employeePreTaxPercentage, int employeeAfterTaxAmount,
			int employeeAfterTaxPercentage, int employeeDeferPreTaxAmount, int employeeDeferPreTaxPercentage,
			int employeeYearToDate, int employerYearToDate, int rolloverContributionPercentage,
			int rolloverContributionAmount) {
		super();
		this._id = _id;
		this.securityIdType = securityIdType;
		this.EmployerMatchPercentage = employerMatchPercentage;
		EmployerMatchAmount = employerMatchAmount;
		EmployeePreTaxAmount = employeePreTaxAmount;
		EmployeePreTaxPercentage = employeePreTaxPercentage;
		EmployeeAfterTaxAmount = employeeAfterTaxAmount;
		EmployeeAfterTaxPercentage = employeeAfterTaxPercentage;
		EmployeeDeferPreTaxAmount = employeeDeferPreTaxAmount;
		EmployeeDeferPreTaxPercentage = employeeDeferPreTaxPercentage;
		EmployeeYearToDate = employeeYearToDate;
		EmployerYearToDate = employerYearToDate;
		RolloverContributionPercentage = rolloverContributionPercentage;
		RolloverContributionAmount = rolloverContributionAmount;
	}*/
	@Override
	public String toString() {
		return "Contribute [_id=" + _id + ", securityIdType=" + securityIdType + ", EmployerMatchPercentage="
				+ EmployerMatchPercentage + ", EmployerMatchAmount=" + EmployerMatchAmount + ", EmployeePreTaxAmount="
				+ EmployeePreTaxAmount + ", EmployeePreTaxPercentage=" + EmployeePreTaxPercentage
				+ ", EmployeeAfterTaxAmount=" + EmployeeAfterTaxAmount + ", EmployeeAfterTaxPercentage="
				+ EmployeeAfterTaxPercentage + ", EmployeeDeferPreTaxAmount=" + EmployeeDeferPreTaxAmount
				+ ", EmployeeDeferPreTaxPercentage=" + EmployeeDeferPreTaxPercentage + ", EmployeeYearToDate="
				+ EmployeeYearToDate + ", EmployerYearToDate=" + EmployerYearToDate
				+ ", RolloverContributionPercentage=" + RolloverContributionPercentage + ", RolloverContributionAmount="
				+ RolloverContributionAmount + "]";
	}
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public SecurityIdType getSecurityIdType() {
		return securityIdType;
	}
	public void setSecurityIdType(SecurityIdType securityIdType) {
		this.securityIdType = securityIdType;
	}
	public int getEmployerMatchPercentage() {
		return EmployerMatchPercentage;
	}
	public void setEmployerMatchPercentage(int employerMatchPercentage) {
		EmployerMatchPercentage = employerMatchPercentage;
	}
	public int getEmployerMatchAmount() {
		return EmployerMatchAmount;
	}
	public void setEmployerMatchAmount(int employerMatchAmount) {
		EmployerMatchAmount = employerMatchAmount;
	}
	public int getEmployeePreTaxAmount() {
		return EmployeePreTaxAmount;
	}
	public void setEmployeePreTaxAmount(int employeePreTaxAmount) {
		EmployeePreTaxAmount = employeePreTaxAmount;
	}
	public int getEmployeePreTaxPercentage() {
		return EmployeePreTaxPercentage;
	}
	public void setEmployeePreTaxPercentage(int employeePreTaxPercentage) {
		EmployeePreTaxPercentage = employeePreTaxPercentage;
	}
	public int getEmployeeAfterTaxAmount() {
		return EmployeeAfterTaxAmount;
	}
	public void setEmployeeAfterTaxAmount(int employeeAfterTaxAmount) {
		EmployeeAfterTaxAmount = employeeAfterTaxAmount;
	}
	public int getEmployeeAfterTaxPercentage() {
		return EmployeeAfterTaxPercentage;
	}
	public void setEmployeeAfterTaxPercentage(int employeeAfterTaxPercentage) {
		EmployeeAfterTaxPercentage = employeeAfterTaxPercentage;
	}
	public int getEmployeeDeferPreTaxAmount() {
		return EmployeeDeferPreTaxAmount;
	}
	public void setEmployeeDeferPreTaxAmount(int employeeDeferPreTaxAmount) {
		EmployeeDeferPreTaxAmount = employeeDeferPreTaxAmount;
	}
	public int getEmployeeDeferPreTaxPercentage() {
		return EmployeeDeferPreTaxPercentage;
	}
	public void setEmployeeDeferPreTaxPercentage(int employeeDeferPreTaxPercentage) {
		EmployeeDeferPreTaxPercentage = employeeDeferPreTaxPercentage;
	}
	public int getEmployeeYearToDate() {
		return EmployeeYearToDate;
	}
	public void setEmployeeYearToDate(int employeeYearToDate) {
		EmployeeYearToDate = employeeYearToDate;
	}
	public int getEmployerYearToDate() {
		return EmployerYearToDate;
	}
	public void setEmployerYearToDate(int employerYearToDate) {
		EmployerYearToDate = employerYearToDate;
	}
	public int getRolloverContributionPercentage() {
		return RolloverContributionPercentage;
	}
	public void setRolloverContributionPercentage(int rolloverContributionPercentage) {
		RolloverContributionPercentage = rolloverContributionPercentage;
	}
	public int getRolloverContributionAmount() {
		return RolloverContributionAmount;
	}
	public void setRolloverContributionAmount(int rolloverContributionAmount) {
		RolloverContributionAmount = rolloverContributionAmount;
	}
	
	
	 
	

	
	


}
