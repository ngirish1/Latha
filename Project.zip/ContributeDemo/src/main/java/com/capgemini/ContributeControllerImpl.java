package com.capgemini;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.conrribute.entity.Contribute;
import com.capgemini.contribute.repository.ContributeRepo;
import com.capgemini.contribute.repository.UserRepository;
import com.capgemini.model.User;

@Component
@RequestMapping(value = "/StargateDDABankingApp/Contribute", produces = "application/json")
public  class ContributeControllerImpl implements ContributeController {
	private final Logger log = LoggerFactory.getLogger(ContributeController.class);
	
	@Autowired
	ContributeRepo contributeRepo;
	@Autowired
	UserRepository userRepository;
	
	@Override
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getObjectById( @PathVariable
	        String id) {
		// TODO Auto-generated method stub
		 log.info("Getting user with ID: {}.", id);
		 Optional<Contribute> result = contributeRepo.findById(id);
		 Contribute contribute = result.get();
		 log.info(""+contribute);
		 return new ResponseEntity<Contribute>(contribute,HttpStatus.OK);
		
		
		
		
	}
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public User getUser(@RequestParam(required = false, value = "sortby") String sortBy ) {
		log.info("Getting user with ID: {}.", sortBy);
		Optional<User> result1 = userRepository.findById(sortBy);
		User user1 = result1.get();
		return user1;
	}
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public User addNewUsers(@RequestBody User user) {
		log.info("Saving user.");
		return userRepository.save(user);
	}

}
