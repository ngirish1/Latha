package com.capgemini.exception;

public class UserNotFoundException extends RuntimeException {

	public UserNotFoundException(String id) {
		// TODO Auto-generated constructor stub
		throw new UserNotFoundException(" User Details Not Found");
	}

}
