package com.capgemini.main;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.capgemini.conrribute.entity.Contribute;
import com.capgemini.contribute.repository.ContributeRepo;
import com.capgemini.model.SecurityIdType;

@SpringBootApplication
@ComponentScan("com.capgemini")
@Configuration
@EnableMongoRepositories(basePackageClasses  = ContributeRepo.class)
public class ContributeDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContributeDemoApplication.class, args);
	}
	
	/*@Bean
    CommandLineRunner commandLineRunner(ContributeRepo contriRepository) {
        return strings -> {
        	contriRepository.save(new Contribute("12Ls", SecurityIdType.ISIN, 2000, 30, 4000, 3210, 2341, 2391, 2345, 100, 29010, 272, 212, 3563));
            //userRepository.save(new Users(2, "Sam", "Operations", 2000L));
        };
    }*/
}
